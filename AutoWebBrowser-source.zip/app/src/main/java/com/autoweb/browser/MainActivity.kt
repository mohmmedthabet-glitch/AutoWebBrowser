package com.autoweb.browser

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import android.graphics.Color
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.view.KeyEvent
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("autoweb", Context.MODE_PRIVATE) }
    private val bookmarks = mutableListOf<String>()
    private val history = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        loadLists()
        buildUi()
        web.loadUrl("https://www.google.com")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17, 24, 39))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 8, 8, 4)
        }
        address = EditText(this).apply {
            hint = "ابحث أو أدخل عنوان الموقع"
            textSize = 14f
            singleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setSelectAllOnFocus(true)
            imeOptions = EditorInfo.IME_ACTION_GO
            setBackgroundColor(Color.rgb(42, 52, 68))
        }
        top.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        top.addView(makeButton("اذهب") { navigate(address.text.toString()) })
        root.addView(top)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        controls.addView(makeButton("رجوع") { if (web.canGoBack()) web.goBack() })
        controls.addView(makeButton("تقدم") { if (web.canGoForward()) web.goForward() })
        controls.addView(makeButton("تحديث") { web.reload() })
        controls.addView(makeButton("الرئيسية") { web.loadUrl("https://www.google.com") })
        controls.addView(makeButton("★") { addBookmark() })
        controls.addView(makeButton("المفضلة") { showBookmarks() })
        controls.addView(makeButton("السجل") { showHistory() })
        root.addView(controls)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, 4))

        web = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.mediaPlaybackRequiresUserGesture = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            CookieManager.getInstance().setAcceptCookie(true)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    address.setText(url ?: "")
                    if (!url.isNullOrBlank()) addHistory(url)
                }
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    return false
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }
            setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
                try {
                    val request = DownloadManager.Request(Uri.parse(url))
                        .setMimeType(mimeType)
                        .addRequestHeader("User-Agent", userAgent)
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setTitle(android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType))
                        .setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS,
                            android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType))
                    (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                    Toast.makeText(this@MainActivity, "بدأ التنزيل", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر بدء التنزيل", Toast.LENGTH_SHORT).show()
                }
            })
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        address.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                navigate(address.text.toString())
                true
            } else false
        }

        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            setPadding(5, 0, 5, 0)
            setOnClickListener { action() }
        }

    private fun navigate(input: String) {
        val value = input.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(".") && !value.contains(" ") -> "https://$value"
            else -> "https://www.google.com/search?q=" + Uri.encode(value)
        }
        web.loadUrl(url)
    }

    private fun addBookmark() {
        val url = web.url ?: return
        if (!bookmarks.contains(url)) bookmarks.add(url)
        saveLists()
        Toast.makeText(this, "تمت إضافة الصفحة للمفضلة", Toast.LENGTH_SHORT).show()
    }

    private fun addHistory(url: String) {
        if (history.lastOrNull() != url) {
            history.add(url)
            if (history.size > 300) history.removeAt(0)
            saveLists()
        }
    }

    private fun showBookmarks() = showList("المفضلة", bookmarks)
    private fun showHistory() = showList("سجل التصفح", history.asReversed())

    private fun showList(title: String, items: List<String>) {
        if (items.isEmpty()) {
            Toast.makeText(this, "لا توجد عناصر بعد", Toast.LENGTH_SHORT).show()
            return
        }
        val choices = items.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(choices) { _, which -> web.loadUrl(choices[which]) }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun loadLists() {
        readArray("bookmarks").forEach { bookmarks.add(it) }
        readArray("history").forEach { history.add(it) }
    }

    private fun readArray(key: String): List<String> {
        return try {
            val arr = JSONArray(prefs.getString(key, "[]"))
            (0 until arr.length()).map { arr.getString(it) }
        } catch (_: Exception) { emptyList() }
    }

    private fun saveLists() {
        fun json(items: List<String>) = JSONArray().also { a -> items.forEach { a.put(it) } }.toString()
        prefs.edit().putString("bookmarks", json(bookmarks))
            .putString("history", json(history)).apply()
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
